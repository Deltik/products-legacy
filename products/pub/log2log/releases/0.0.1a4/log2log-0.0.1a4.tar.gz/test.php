<?php

header("Content-Type: text/plain");
print_r(ini_get_all());

?>
