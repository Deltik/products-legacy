<?php

/*****************************************\
| MuSeSPinger Updater: Server-Side Script |
\*****************************************/

$version = "2.1.0b";
$files = array(
"index.php",
"status.php",
"img.php",
"style.css",
"online.png",
"offline.png");
$fixedfiles = array(
"config.php",
"language.php");
$filesdel = array(
);
$changelog = array(
"2.0.0a" => "Initial Release",
"2.0.1a" => "Added Background Communications",
"2.0.1a1" => "Update System Test",
"2.0.1a2" => "Fixed Update System",
"2.0.1a3" => "Cleaned up source code to meet the Deltik Programming Syntax Standard",
"2.0.1a4" => "Fixed a critical Update Manager bug in which only the last update server was considered for use",
"2.1.0a" => "Improved update system to eliminate 500 Internal Server Errors",
"2.1.0b" => "Implemented image output feature",
);

// Tell everybody the latest version if something requests it
if ($_REQUEST['data'] == "version"){
  die ($version);
  }

// Send Updated File (v2.1.0a and above)
if ($_REQUEST['file'])
  {
  // if() Security Check
  if (strpos("/", $_REQUEST['file']) === false)
    {
    die(file_get_contents($_REQUEST['file'].".txt"));
    }
    else
    {
    die("H4X0R PR3V3NT!0N");
    }
  }

// Outputting the instructions for the client. The order is very strict!
//   So, this is what happens:
//   The client sends their version to the server.
//   Then the server handles that version appropriately.

if (version_compare($_REQUEST['version'], "2.1.0a", "<=")){
  echo "Version: $version";
  echo '<br />';
  echo "Changelog BEGIN<br />";
  $i = 0;
  foreach($changelog as $v => $value) {
    if (version_compare($_REQUEST['version'], $v, "<") && version_compare($v, $version, "<="))
      echo '&bull; '.$value.' in v'.$v.'.<br />';
    $i++;
    }
  echo "Changelog END<br />";
  echo "Files: ".count($files);
  echo '<br />';
  for ($i=0; $i<count($files); $i++){
    echo $files[$i];
    echo '<br />';
    }
  echo "Configuration Files: ".count($fixedfiles);
  echo '<br />';
  for ($i=0; $i<=count($fixedfiles); $i++){
    echo $fixedfiles[$i];
    echo '<br />';
    }
  }

?>
