<title>IsMyWebsite Server Status Checker</title>

<?php

error_reporting(0);

	if(is_writable('index.php')) {
		echo 'Running automatic update...<br/>Downloading online.gif...';
		copy('http://www.deltik.org/Deltik/online.gif', 'online.gif');
		if(!copy('http://www.deltik.org/Deltik/online.gif', 'online.gif'))
			die('<span style="color: #FF0000"><b>[FAILED]</b> Error: Unable to copy! Setup cannot continue until the directory index.php is in is CHMODded to 777. If the directory is 777, then check to see if copying is allowed.</span>');
		echo '<br/>Downloading offline.gif...';
		copy('http://www.deltik.org/Deltik/offline.gif', 'offline.gif');
		if(!copy('http://www.deltik.org/Deltik/offline.gif', 'offline.gif'))
			die('<span style="color: #FF0000"><b>[FAILED]</b> Error: Unable to copy! Setup cannot continue until the directory index.php is in is CHMODded to 777. If the directory is 777, then check to see if copying is allowed.</span>');
		echo '<br/>Downloading index.php... ';
		copy('http://www.deltik.org/Deltik/update.txt', 'index.php');
		if(!copy('http://www.deltik.org/Deltik/update.txt', 'index.php'))
			die('<span style="color: #FF0000"><b>[FAILED]</b> Error: Unable to copy! Setup cannot continue until the directory index.php is in is CHMODded to 777. If the directory is 777, then check to see if copying is allowed.</span>');
			die('<br/><br/><b>UPDATED! Click <a href=" ">here</a> to run the script.</b>');
		} else {
		echo 'Unable to write to index.php! Please CHMOD this file to 777.';
		}

error_reporting(E_ALL);

?>