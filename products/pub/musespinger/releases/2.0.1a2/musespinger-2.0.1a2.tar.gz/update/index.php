<?php

/*****************************************\
| MuSeSPinger Updater: Server-Side Script |
\*****************************************/

$version = "2.0.1a";
$files = array(
"index.php",
"status.php",
"style.css",
"online.png",
"offline.png");
$fixedfiles = array(
"config.php",
"language.php");
$filesdel = array(
);
$changelog = array(
"2.0.0a" => "Initial Release",
"2.0.1a" => "Added Background Communications",
"2.0.2a" => "Dummy2!");

// Tell everybody the latest version if something requests it
if ($_REQUEST['data'] == "version"){
  die ($version);
  }

// Outputting the instructions for the client. The order is very strict!
//   So, this is what happens:
//   The client sends their version to the server.
//   Then the server handles that version appropriately.

if (version_compare($_REQUEST['version'], "2.1.0a", "<=")){
  echo "Version: $version";
  echo '<br />';
  echo "Changelog BEGIN<br />";
  $i = 0;
  foreach($changelog as $v => $value) {
    if (version_compare($_REQUEST['version'], $v, "<") && version_compare($v, $version, "<="))
      echo '&bull; '.$value.' in v'.$v.'.<br />';
    $i++;
    }
  echo "Changelog END<br />";
  echo "Files: ".count($files);
  echo '<br />';
  for ($i=0; $i<count($files); $i++){
    echo $files[$i];
    echo '<br />';
    }
  echo "Configuration Files: ".count($fixedfiles);
  echo '<br />';
  for ($i=0; $i<=count($fixedfiles); $i++){
    echo $fixedfiles[$i];
    echo '<br />';
    }
  }

?>
