<br>
<?php
echo "In actualality this is not a tunnel at all! Here is what this is. This is a very simple PHP script that its sole purpose is to hide what you do on the internet from your history.<br/> Here is the reason why it is not a tunnel:<br/> It uses your own Internet connection to show the page(not the server's)<br/> In all it is still very useful on a shared computer such as a Library or Internet Cafe since your history can not be tracked. All that appears in the history is this site, not any pages you have viewed. So enjoy this free Technologer Invention!"
?>
<center>
<?php include 'license.html';?>
</center>