<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Technologer Tunnel |</title>
</head>


<body>

<center>
<big><big><big style="font-style: italic;"><big><big>A</big></big></big></big></big><br>

&nbsp;<img style="width: 300px; height: 83px;" alt="Technologer" src="332d3c9544957f40.gif"> <br>

<big style="text-decoration: underline;"><big><big><big>Invention</big></big></big></big><br>

<form action="tunnels.php" method="post"> <input name="$blah" value="Begin Hiding your History!" type="submit">
</form>
<script type="text/javascript"><!--
google_ad_client = "pub-6002461218286378";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
google_ad_channel = "";
google_color_border = "EBEBEB";
google_color_bg = "EBEBEB";
google_color_link = "FFFFFF";
google_color_text = "#010197";
google_color_url = "#0101F1";
google_ui_features = "rc:0";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><br>
<?php include 'license.html';?>
</center>
</body>
</html>
